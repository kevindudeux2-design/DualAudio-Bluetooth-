# Dual Audio v0.2

Prototype Android pour tester la diffusion vers deux récepteurs Bluetooth A2DP simultanément.

## v0.2
- détecte les deux appareils A2DP connectés ;
- affiche modèle, version Android/HyperOS et sorties audio exposées ;
- détecte par réflexion les API système Android de routage multi-appareils ;
- tente de demander le routage vers les deux sorties quand le firmware l'autorise ;
- affiche l'erreur exacte (permission système, API cachée, HAL/vendor, etc.) si le routage est refusé.

Cette version n'utilise ni root ni Shizuku. Sur Android standard, les API capables de sélectionner plusieurs sorties pour le média sont normalement réservées aux applications privilégiées du système. Le test permet de savoir précisément comment le firmware du téléphone réagit.
