package com.kzs.dualaudio.bluetooth

import android.bluetooth.BluetoothDevice
import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build

/**
 * Experimental Android/HyperOS route probe.
 *
 * Android 12+ contains system APIs for selecting multiple preferred output
 * devices, but normal third-party apps are not granted the privileged routing
 * permission. We still probe those APIs so the app can report exactly what the
 * phone exposes and, on a vendor build that allows it, attempt the route.
 */
class SystemRouteProbe(private val context: Context) {

    data class ProbeResult(
        val success: Boolean,
        val report: String
    )

    fun diagnoseAndAttempt(first: BluetoothDevice?, second: BluetoothDevice?): ProbeResult {
        val audio = context.getSystemService(AudioManager::class.java)
        val lines = mutableListOf<String>()
        lines += "Téléphone : ${Build.MANUFACTURER} ${Build.MODEL}"
        lines += "Android : ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"
        lines += "Build : ${Build.DISPLAY}"

        val outputs = audio.getDevices(AudioManager.GET_DEVICES_OUTPUTS).toList()
        val btOutputs = outputs.filter { it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP }
        lines += "Sorties A2DP visibles par AudioManager : ${btOutputs.size}"
        btOutputs.forEachIndexed { index, device ->
            val name = device.productName?.toString()?.ifBlank { "Bluetooth" } ?: "Bluetooth"
            val address = runCatching { device.address }.getOrDefault("")
            lines += "  ${index + 1}. $name${if (address.isNotBlank()) " [$address]" else ""}"
        }

        if (first == null || second == null) {
            lines += "Échec : sélectionne deux appareils avant le test."
            return ProbeResult(false, lines.joinToString("\n"))
        }

        val targetOutputs = outputs.filter { output ->
            output.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP &&
                (matches(output, first) || matches(output, second))
        }
        lines += "Correspondances avec les 2 appareils choisis : ${targetOutputs.size}/2"

        // Probe Android's multi-device system API using reflection. This keeps
        // the app buildable with the public SDK while showing the precise result
        // on this particular HyperOS firmware.
        try {
            val strategyClass = Class.forName("android.media.audiopolicy.AudioProductStrategy")
            val getStrategies = strategyClass.getDeclaredMethod("getAudioProductStrategies")
            val strategies = (getStrategies.invoke(null) as? List<*>)?.filterNotNull().orEmpty()
            lines += "API AudioProductStrategy : présente (${strategies.size} stratégie(s))"

            val method = AudioManager::class.java.declaredMethods.firstOrNull {
                it.name == "setPreferredDevicesForStrategy" && it.parameterTypes.size == 2
            }
            if (method == null) {
                lines += "API multi-sortie système : méthode absente sur ce firmware."
                return ProbeResult(false, lines.joinToString("\n"))
            }
            lines += "API multi-sortie système : méthode détectée."

            if (targetOutputs.size < 2) {
                lines += "Impossible de tenter le routage : Android n'expose pas les 2 sorties A2DP comme AudioDeviceInfo distincts."
                return ProbeResult(false, lines.joinToString("\n"))
            }

            val attrClass = Class.forName("android.media.AudioDeviceAttributes")
            val ctor = attrClass.declaredConstructors.firstOrNull { c ->
                c.parameterTypes.size == 1 && c.parameterTypes[0] == AudioDeviceInfo::class.java
            }
            if (ctor == null) {
                lines += "Constructeur AudioDeviceAttributes(AudioDeviceInfo) non accessible."
                return ProbeResult(false, lines.joinToString("\n"))
            }
            ctor.isAccessible = true
            val attrs = targetOutputs.take(2).map { ctor.newInstance(it) }

            // Pick the media strategy when possible; otherwise try each strategy
            // until the framework accepts one. A normal app will usually be
            // rejected with SecurityException due to MODIFY_AUDIO_ROUTING.
            method.isAccessible = true
            var lastError: Throwable? = null
            for (strategy in strategies) {
                try {
                    val result = method.invoke(audio, strategy, attrs)
                    val accepted = (result as? Boolean) ?: true
                    if (accepted) {
                        lines += "Routage demandé aux 2 sorties : accepté par le framework."
                        lines += "Teste maintenant une musique pour vérifier si HyperOS garde réellement les 2 sorties actives."
                        return ProbeResult(true, lines.joinToString("\n"))
                    }
                } catch (t: Throwable) {
                    lastError = unwrap(t)
                }
            }

            val err = lastError
            if (err is SecurityException) {
                lines += "Blocage système : permission privilégiée de routage refusée."
                lines += "Conclusion : cette ROM HyperOS réserve la vraie multi-sortie aux composants système/constructeur."
            } else if (err != null) {
                lines += "Tentative refusée : ${err.javaClass.simpleName}: ${err.message ?: "sans détail"}"
            } else {
                lines += "Le framework n'a accepté aucune stratégie média."
            }
        } catch (t: Throwable) {
            val err = unwrap(t)
            lines += "API système inaccessible : ${err.javaClass.simpleName}: ${err.message ?: "sans détail"}"
            if (err.javaClass.simpleName.contains("Hidden", ignoreCase = true)) {
                lines += "Android bloque l'accès aux API cachées pour les applications normales."
            }
        }

        return ProbeResult(false, lines.joinToString("\n"))
    }

    private fun matches(info: AudioDeviceInfo, bt: BluetoothDevice): Boolean {
        val infoAddress = runCatching { info.address }.getOrDefault("")
        if (infoAddress.isNotBlank() && infoAddress.equals(bt.address, ignoreCase = true)) return true
        val infoName = info.productName?.toString()?.trim().orEmpty()
        val btName = runCatching { bt.name.orEmpty() }.getOrDefault("")
        return infoName.isNotBlank() && btName.isNotBlank() && infoName.equals(btName, ignoreCase = true)
    }

    private fun unwrap(t: Throwable): Throwable {
        var current = t
        while (current.cause != null && current.cause !== current) current = current.cause!!
        return current
    }
}
