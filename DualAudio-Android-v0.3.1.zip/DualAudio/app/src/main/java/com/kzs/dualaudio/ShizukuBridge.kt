package com.kzs.dualaudio

import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

object ShizukuBridge {
    const val REQUEST_CODE = 4203

    fun isAvailable(): Boolean = try { Shizuku.pingBinder() } catch (_: Throwable) { false }

    fun hasPermission(): Boolean = try {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) { false }

    fun requestPermission() {
        if (isAvailable() && !hasPermission()) {
            Shizuku.requestPermission(REQUEST_CODE)
        }
    }

    @Suppress("DEPRECATION")
    suspend fun run(command: String): String = withContext(Dispatchers.IO) {
        if (!isAvailable()) return@withContext "Shizuku n'est pas démarré."
        if (!hasPermission()) return@withContext "Permission Shizuku non accordée."
        try {
            val process = Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)
            val stdout = process.inputStream.bufferedReader().use { it.readText() }
            val stderr = process.errorStream.bufferedReader().use { it.readText() }
            val code = process.waitFor()
            buildString {
                append("code=").append(code).append('\n')
                if (stdout.isNotBlank()) append(stdout.trim())
                if (stderr.isNotBlank()) {
                    if (stdout.isNotBlank()) append("\n--- stderr ---\n")
                    append(stderr.trim())
                }
            }
        } catch (t: Throwable) {
            "Erreur Shizuku: ${t.javaClass.simpleName}: ${t.message}"
        }
    }

    suspend fun diagnostic(): String {
        val id = run("id")
        val audioHelp = run("cmd audio help 2>&1 | head -n 80")
        val audioDump = run("dumpsys audio 2>/dev/null | grep -i -E 'A2DP|Bluetooth|device|route' | head -n 120")
        val btDump = run("dumpsys bluetooth_manager 2>/dev/null | grep -i -E 'A2DP|active|connected' | head -n 100")
        return buildString {
            appendLine("=== Identité Shizuku ===")
            appendLine(id)
            appendLine()
            appendLine("=== cmd audio help ===")
            appendLine(audioHelp)
            appendLine()
            appendLine("=== dumpsys audio (filtré) ===")
            appendLine(audioDump)
            appendLine()
            appendLine("=== Bluetooth manager (filtré) ===")
            appendLine(btDump)
        }
    }
}
