package com.kzs.dualaudio

import android.app.Application
import android.bluetooth.BluetoothDevice
import androidx.lifecycle.AndroidViewModel
import com.kzs.dualaudio.bluetooth.BluetoothAudioManager
import com.kzs.dualaudio.bluetooth.SystemRouteProbe

class MainViewModel(app: Application) : AndroidViewModel(app) {
    val bt = BluetoothAudioManager(app)
    val bonded = bt.bondedDevices
    val connected = bt.connectedA2dp
    private val routeProbe = SystemRouteProbe(app)

    var firstAddress: String? = null
        private set
    var secondAddress: String? = null
        private set

    fun selectFirst(device: BluetoothDevice) { firstAddress = device.address }
    fun selectSecond(device: BluetoothDevice) { secondAddress = device.address }

    fun testSystemRoute(first: BluetoothDevice?, second: BluetoothDevice?): SystemRouteProbe.ProbeResult =
        routeProbe.diagnoseAndAttempt(first, second)

    fun start() = bt.start()
    fun stop() = bt.stop()
    fun refresh() = bt.refresh()
}
