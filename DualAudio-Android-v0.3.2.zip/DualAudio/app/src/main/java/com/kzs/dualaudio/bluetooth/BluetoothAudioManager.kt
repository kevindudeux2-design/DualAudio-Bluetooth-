package com.kzs.dualaudio.bluetooth

import android.Manifest
import android.bluetooth.BluetoothA2dp
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.content.Intent
import android.content.BroadcastReceiver
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.provider.Settings
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Public-API Bluetooth layer.
 *
 * Important: Android's public API exposes the list of connected A2DP devices,
 * but it does not expose a supported API that makes two classic A2DP sinks
 * simultaneously active for media on every phone. This class therefore detects
 * and selects two targets, while the actual dual-output backend remains device/
 * vendor/system dependent.
 */
class BluetoothAudioManager(private val context: Context) : BluetoothProfile.ServiceListener {
    private var receiverRegistered = false
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
            when (intent?.action) {
                BluetoothA2dp.ACTION_CONNECTION_STATE_CHANGED,
                BluetoothDevice.ACTION_BOND_STATE_CHANGED,
                BluetoothAdapter.ACTION_STATE_CHANGED -> refresh()
            }
        }
    }
    private val bluetoothManager = context.getSystemService(BluetoothManager::class.java)
    private val adapter: BluetoothAdapter? = bluetoothManager?.adapter
    private var a2dp: BluetoothA2dp? = null

    private val _bondedDevices = MutableStateFlow<List<BluetoothDevice>>(emptyList())
    val bondedDevices: StateFlow<List<BluetoothDevice>> = _bondedDevices.asStateFlow()

    private val _connectedA2dp = MutableStateFlow<List<BluetoothDevice>>(emptyList())
    val connectedA2dp: StateFlow<List<BluetoothDevice>> = _connectedA2dp.asStateFlow()

    fun hasConnectPermission(): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    fun start() {
        if (!hasConnectPermission()) return
        refreshBonded()
        if (!receiverRegistered) {
            val filter = IntentFilter().apply {
                addAction(BluetoothA2dp.ACTION_CONNECTION_STATE_CHANGED)
                addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED)
                addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
            }
            runCatching { context.registerReceiver(receiver, filter) }
            receiverRegistered = true
        }
        if (a2dp == null) adapter?.getProfileProxy(context, this, BluetoothProfile.A2DP)
        else refresh()
    }

    fun stop() {
        a2dp?.let { adapter?.closeProfileProxy(BluetoothProfile.A2DP, it) }
        a2dp = null
        if (receiverRegistered) {
            runCatching { context.unregisterReceiver(receiver) }
            receiverRegistered = false
        }
    }

    fun refresh() {
        if (!hasConnectPermission()) return
        refreshBonded()
        _connectedA2dp.value = runCatching { a2dp?.connectedDevices.orEmpty() }.getOrDefault(emptyList())
    }

    private fun refreshBonded() {
        _bondedDevices.value = runCatching {
            adapter?.bondedDevices?.sortedBy { it.name ?: it.address }.orEmpty()
        }.getOrDefault(emptyList())
    }

    fun openBluetoothSettings() {
        context.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    override fun onServiceConnected(profile: Int, proxy: BluetoothProfile?) {
        if (profile == BluetoothProfile.A2DP) {
            a2dp = proxy as? BluetoothA2dp
            refresh()
        }
    }

    override fun onServiceDisconnected(profile: Int) {
        if (profile == BluetoothProfile.A2DP) {
            a2dp = null
            _connectedA2dp.value = emptyList()
        }
    }
}
