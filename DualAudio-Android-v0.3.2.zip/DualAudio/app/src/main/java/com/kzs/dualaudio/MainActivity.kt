package com.kzs.dualaudio

import android.Manifest
import android.bluetooth.BluetoothDevice
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch
import rikka.shizuku.Shizuku

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { vm.start(); Handler(Looper.getMainLooper()).postDelayed({ vm.refresh() }, 700) }

    private val shizukuPermissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, _ ->
        if (requestCode == ShizukuBridge.REQUEST_CODE) recreate()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Shizuku.addRequestPermissionResultListener(shizukuPermissionListener)
        requestBtPermissionsIfNeeded()
        setContent { DualAudioApp(vm) }
    }

    override fun onStart() {
        super.onStart()
        if (vm.bt.hasConnectPermission()) vm.start()
    }

    override fun onResume() {
        super.onResume()
        if (vm.bt.hasConnectPermission()) {
            vm.start()
            Handler(Looper.getMainLooper()).postDelayed({ vm.refresh() }, 700)
            Handler(Looper.getMainLooper()).postDelayed({ vm.refresh() }, 1800)
        }
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(shizukuPermissionListener)
        vm.stop()
        super.onDestroy()
    }

    private fun requestBtPermissionsIfNeeded() {
        val connect = ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
        val scan = ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN)
        if (connect != PackageManager.PERMISSION_GRANTED || scan != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DualAudioApp(vm: MainViewModel) {
    val bonded by vm.bonded.collectAsState()
    val connected by vm.connected.collectAsState()
    var first by remember { mutableStateOf<BluetoothDevice?>(null) }
    var second by remember { mutableStateOf<BluetoothDevice?>(null) }
    var picker by remember { mutableIntStateOf(0) }
    var message by remember { mutableStateOf<String?>(null) }
    var shizukuReport by remember { mutableStateOf<String?>(null) }
    var running by remember { mutableStateOf(false) }
    var shizukuAvailable by remember { mutableStateOf(ShizukuBridge.isAvailable()) }
    var shizukuGranted by remember { mutableStateOf(ShizukuBridge.hasPermission()) }
    val btPermission = vm.bt.hasConnectPermission()
    val scope = rememberCoroutineScope()

    LaunchedEffect(connected) {
        if (first == null) first = connected.getOrNull(0)
        if (second == null) second = connected.getOrNull(1)
        shizukuAvailable = ShizukuBridge.isAvailable()
        shizukuGranted = ShizukuBridge.hasPermission()
    }

    MaterialTheme {
        Scaffold(topBar = { TopAppBar(title = { Text("Dual Audio v0.3.2") }) }) { padding ->
            Column(
                modifier = Modifier.padding(padding).padding(16.dp).fillMaxSize().verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("HyperOS / Android multi-sortie + Shizuku", style = MaterialTheme.typography.titleMedium)
                Text("Sélectionne les 2 appareils déjà connectés en Bluetooth.")
                if (!btPermission) {
                    Card { Text("Permission Bluetooth non accordée. Ferme puis rouvre l’app pour accepter l’autorisation Bluetooth.", modifier = Modifier.padding(12.dp)) }
                }

                DeviceSlot("Sortie 1", first, connected) { picker = 1 }
                DeviceSlot("Sortie 2", second, connected) { picker = 2 }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.start(); vm.refresh() }) { Text("Actualiser") }
                    OutlinedButton(onClick = { vm.bt.openBluetoothSettings() }) { Text("Bluetooth") }
                }

                Button(
                    enabled = first != null && second != null,
                    onClick = {
                        vm.refresh()
                        message = vm.testSystemRoute(first, second).report
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("TESTER ANDROID / HYPEROS") }

                message?.let { Card { Text(it, modifier = Modifier.padding(12.dp)) } }

                HorizontalDivider()
                Text("Mode Shizuku", style = MaterialTheme.typography.titleMedium)
                Text("Service : ${if (shizukuAvailable) "détecté" else "non démarré"}")
                Text("Permission : ${if (shizukuGranted) "accordée" else "non accordée"}")

                if (shizukuAvailable && !shizukuGranted) {
                    Button(onClick = { ShizukuBridge.requestPermission() }, modifier = Modifier.fillMaxWidth()) {
                        Text("AUTORISER DUAL AUDIO DANS SHIZUKU")
                    }
                }

                Button(
                    enabled = shizukuAvailable && shizukuGranted && !running,
                    onClick = {
                        running = true
                        scope.launch {
                            shizukuReport = ShizukuBridge.diagnostic()
                            running = false
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text(if (running) "DIAGNOSTIC EN COURS…" else "DIAGNOSTIC AUDIO AVEC SHIZUKU") }

                shizukuReport?.let {
                    Card { Text(it, modifier = Modifier.padding(12.dp)) }
                }

                HorizontalDivider()
                Text("Permission Bluetooth : ${if (btPermission) "OK" else "REFUSÉE"}")
                Text("Appareils appairés : ${bonded.size}")
                Text("A2DP connectés : ${connected.size}")
                connected.forEach { Text("• ${safeName(it)}") }

                Text(
                    "v0.3.2 — détection Bluetooth renforcée. Shizuku donne à l'application une identité shell/ADB pour inspecter les services audio et Bluetooth d'HyperOS. Cette version diagnostique les commandes réellement disponibles avant d'essayer une modification de routage dans la prochaine étape. Elle ne promet pas encore que le firmware autorise deux sorties A2DP actives.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }

        if (picker != 0) {
            ModalBottomSheet(onDismissRequest = { picker = 0 }) {
                Text("Choisir la sortie $picker", modifier = Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.titleLarge)
                LazyColumn(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                    items(bonded, key = { it.address }) { device ->
                        Row(
                            modifier = Modifier.fillMaxWidth().clickable {
                                if (picker == 1) { first = device; vm.selectFirst(device) }
                                else { second = device; vm.selectSecond(device) }
                                picker = 0
                            }.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(safeName(device))
                                Text(device.address, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DeviceSlot(
    label: String,
    device: BluetoothDevice?,
    connected: List<BluetoothDevice>,
    onClick: () -> Unit
) {
    val isConnected = device != null && connected.any { it.address == device.address }
    Card(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(Modifier.padding(16.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(label, style = MaterialTheme.typography.labelLarge)
                Text(device?.let(::safeName) ?: "Sélectionner un appareil")
            }
            if (device != null) Text(if (isConnected) "Connecté" else "Non connecté")
        }
    }
}

private fun safeName(device: BluetoothDevice): String = try {
    device.name ?: "Appareil Bluetooth"
} catch (_: SecurityException) {
    "Appareil Bluetooth"
}
