package com.kzs.dualaudio

import android.Manifest
import android.bluetooth.BluetoothDevice
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { vm.start() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestBtPermissionsIfNeeded()
        setContent { DualAudioApp(vm) }
    }

    override fun onStart() {
        super.onStart()
        if (vm.bt.hasConnectPermission()) vm.start()
    }

    override fun onStop() {
        vm.stop()
        super.onStop()
    }

    private fun requestBtPermissionsIfNeeded() {
        val connect = ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
        val scan = ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN)
        if (connect != PackageManager.PERMISSION_GRANTED || scan != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DualAudioApp(vm: MainViewModel) {
    val bonded by vm.bonded.collectAsState()
    val connected by vm.connected.collectAsState()
    var first by remember { mutableStateOf<BluetoothDevice?>(null) }
    var second by remember { mutableStateOf<BluetoothDevice?>(null) }
    var picker by remember { mutableIntStateOf(0) }
    var message by remember { mutableStateOf<String?>(null) }
    var testSuccess by remember { mutableStateOf(false) }

    LaunchedEffect(connected) {
        if (first == null) first = connected.getOrNull(0)
        if (second == null) second = connected.getOrNull(1)
    }

    MaterialTheme {
        Scaffold(topBar = { TopAppBar(title = { Text("Dual Audio v0.2") }) }) { padding ->
            Column(
                modifier = Modifier.padding(padding).padding(16.dp).fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("HyperOS / Android multi-sortie", style = MaterialTheme.typography.titleMedium)
                Text("Sélectionne les 2 appareils déjà connectés en Bluetooth.")

                DeviceSlot("Sortie 1", first, connected) { picker = 1 }
                DeviceSlot("Sortie 2", second, connected) { picker = 2 }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.refresh() }) { Text("Actualiser") }
                    OutlinedButton(onClick = { vm.bt.openBluetoothSettings() }) { Text("Bluetooth") }
                }

                Button(
                    enabled = first != null && second != null,
                    onClick = {
                        vm.refresh()
                        val result = vm.testSystemRoute(first, second)
                        testSuccess = result.success
                        message = result.report
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("FORCER / TESTER LA DOUBLE SORTIE") }

                message?.let {
                    Card(
                        colors = if (testSuccess) CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                        else CardDefaults.cardColors()
                    ) {
                        Text(it, modifier = Modifier.padding(12.dp))
                    }
                }

                HorizontalDivider()
                Text("A2DP connectés : ${connected.size}")
                connected.forEach { Text("• ${safeName(it)}") }

                Spacer(Modifier.weight(1f))
                Text(
                    "v0.2 — teste les API de routage multi-appareils d'Android/HyperOS et affiche la raison exacte si le firmware refuse l'accès. Aucun root n'est utilisé.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }

        if (picker != 0) {
            ModalBottomSheet(onDismissRequest = { picker = 0 }) {
                Text("Choisir la sortie $picker", modifier = Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.titleLarge)
                LazyColumn(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                    items(bonded, key = { it.address }) { device ->
                        Row(
                            modifier = Modifier.fillMaxWidth().clickable {
                                if (picker == 1) { first = device; vm.selectFirst(device) }
                                else { second = device; vm.selectSecond(device) }
                                picker = 0
                            }.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(safeName(device))
                                Text(device.address, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DeviceSlot(
    label: String,
    device: BluetoothDevice?,
    connected: List<BluetoothDevice>,
    onClick: () -> Unit
) {
    val isConnected = device != null && connected.any { it.address == device.address }
    Card(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(Modifier.padding(16.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(label, style = MaterialTheme.typography.labelLarge)
                Text(device?.let(::safeName) ?: "Sélectionner un appareil")
            }
            if (device != null) Text(if (isConnected) "Connecté" else "Non connecté")
        }
    }
}

private fun safeName(device: BluetoothDevice): String = try {
    device.name ?: "Appareil Bluetooth"
} catch (_: SecurityException) {
    "Appareil Bluetooth"
}
