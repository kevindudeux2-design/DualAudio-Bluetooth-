# Dual Audio — prototype Android

Prototype Android/Kotlin destiné à sélectionner deux appareils Bluetooth A2DP (par exemple une JBL PartyBox et un autoradio) et à vérifier s'ils sont connectés simultanément.

## Ce qui fonctionne
- Permissions Bluetooth Android 12+.
- Liste des appareils appairés.
- Sélection de deux sorties.
- Détection des appareils A2DP connectés.
- Accès rapide aux réglages Bluetooth.
- Architecture prête à recevoir un backend vendor/root/system.

## Limitation Android importante
Une application Android ordinaire ne dispose pas d'une API publique universelle permettant de rendre **deux récepteurs Bluetooth Classic A2DP actifs simultanément** pour le même flux média. Android expose la connexion A2DP, mais le routage multi-sorties dépend du système/vendor.

Ce prototype ne prétend donc pas contourner cette limitation. Le bouton de test vérifie si les deux appareils sont connectés et explique l'état.

## Pour obtenir une vraie double diffusion
Trois pistes techniques :
1. API/vendor spécifique Xiaomi/HyperOS si une extension multi-A2DP est présente.
2. Application privilégiée/signée système avec modifications de la pile audio/Bluetooth.
3. Backend root/module système modifiant le routage A2DP.

La prochaine étape recommandée est d'effectuer un diagnostic du Xiaomi 13T Pro : version HyperOS, propriétés Bluetooth, services audio/vendor, puis d'implémenter `DualAudioBackend` adapté au téléphone.

## Ouvrir le projet
1. Android Studio récent.
2. `Open` puis sélectionner le dossier `DualAudio`.
3. Laisser Gradle télécharger les dépendances.
4. Brancher le téléphone en USB avec débogage USB activé.
5. Exécuter l'application.

SDK cible : 35, minSdk : 31, Kotlin + Jetpack Compose.
