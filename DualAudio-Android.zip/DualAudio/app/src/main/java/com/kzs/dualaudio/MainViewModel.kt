package com.kzs.dualaudio

import android.app.Application
import android.bluetooth.BluetoothDevice
import androidx.lifecycle.AndroidViewModel
import com.kzs.dualaudio.bluetooth.BluetoothAudioManager

class MainViewModel(app: Application) : AndroidViewModel(app) {
    val bt = BluetoothAudioManager(app)
    val bonded = bt.bondedDevices
    val connected = bt.connectedA2dp

    var firstAddress: String? = null
        private set
    var secondAddress: String? = null
        private set

    fun selectFirst(device: BluetoothDevice) { firstAddress = device.address }
    fun selectSecond(device: BluetoothDevice) { secondAddress = device.address }

    fun start() = bt.start()
    fun stop() = bt.stop()
    fun refresh() = bt.refresh()
}
