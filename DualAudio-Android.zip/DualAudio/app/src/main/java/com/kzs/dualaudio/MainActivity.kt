package com.kzs.dualaudio

import android.Manifest
import android.bluetooth.BluetoothDevice
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { vm.start() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestBtPermissionsIfNeeded()
        setContent { DualAudioApp(vm) }
    }

    override fun onStart() {
        super.onStart()
        if (vm.bt.hasConnectPermission()) vm.start()
    }

    override fun onStop() {
        vm.stop()
        super.onStop()
    }

    private fun requestBtPermissionsIfNeeded() {
        val connect = ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
        val scan = ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN)
        if (connect != PackageManager.PERMISSION_GRANTED || scan != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DualAudioApp(vm: MainViewModel) {
    val bonded by vm.bonded.collectAsState()
    val connected by vm.connected.collectAsState()
    var first by remember { mutableStateOf<BluetoothDevice?>(null) }
    var second by remember { mutableStateOf<BluetoothDevice?>(null) }
    var picker by remember { mutableIntStateOf(0) }
    var message by remember { mutableStateOf<String?>(null) }

    MaterialTheme {
        Scaffold(
            topBar = { TopAppBar(title = { Text("Dual Audio") }) }
        ) { padding ->
            Column(
                modifier = Modifier.padding(padding).padding(16.dp).fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Choisis deux appareils Bluetooth audio.", style = MaterialTheme.typography.titleMedium)

                DeviceSlot("Sortie 1", first, connected) { picker = 1 }
                DeviceSlot("Sortie 2", second, connected) { picker = 2 }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.refresh() }) { Text("Actualiser") }
                    OutlinedButton(onClick = { vm.bt.openBluetoothSettings() }) { Text("Réglages Bluetooth") }
                }

                Button(
                    enabled = first != null && second != null,
                    onClick = {
                        val bothConnected = connected.any { it.address == first?.address } &&
                                connected.any { it.address == second?.address }
                        message = if (bothConnected) {
                            "Les deux appareils sont connectés en A2DP. Android standard ne permet toutefois pas à cette appli de les rendre tous les deux actifs simultanément. Il faut un backend système/vendor pour activer la vraie double diffusion."
                        } else {
                            "Connecte d'abord les deux appareils dans les réglages Bluetooth, puis appuie sur Actualiser."
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("TESTER LA DOUBLE SORTIE") }

                message?.let {
                    Card { Text(it, modifier = Modifier.padding(12.dp)) }
                }

                HorizontalDivider()
                Text("Appareils A2DP actuellement connectés : ${connected.size}")
                connected.forEach { Text("• ${safeName(it)}") }

                Spacer(Modifier.weight(1f))
                Text(
                    "Prototype 0.1 — la sélection de deux appareils fonctionne. La diffusion simultanée Bluetooth classique nécessite une fonction système non exposée par l'API Android publique.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }

        if (picker != 0) {
            ModalBottomSheet(onDismissRequest = { picker = 0 }) {
                Text("Choisir la sortie $picker", modifier = Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.titleLarge)
                LazyColumn(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                    items(bonded, key = { it.address }) { device ->
                        Row(
                            modifier = Modifier.fillMaxWidth().clickable {
                                if (picker == 1) { first = device; vm.selectFirst(device) }
                                else { second = device; vm.selectSecond(device) }
                                picker = 0
                            }.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(safeName(device))
                                Text(device.address, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DeviceSlot(
    label: String,
    device: BluetoothDevice?,
    connected: List<BluetoothDevice>,
    onClick: () -> Unit
) {
    val isConnected = device != null && connected.any { it.address == device.address }
    Card(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(Modifier.padding(16.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(label, style = MaterialTheme.typography.labelLarge)
                Text(device?.let(::safeName) ?: "Sélectionner un appareil")
            }
            if (device != null) Text(if (isConnected) "Connecté" else "Non connecté")
        }
    }
}

private fun safeName(device: BluetoothDevice): String = try {
    device.name ?: "Appareil Bluetooth"
} catch (_: SecurityException) {
    "Appareil Bluetooth"
}
